**RUNNING THE PROGRAM**
Running the servers from outside of the bin folder can cause memory issues.
To avoid this run it from inside /bin/